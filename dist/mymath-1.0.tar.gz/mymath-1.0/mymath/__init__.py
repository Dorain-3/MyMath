from mymath.math1 import *
from mymath.math2 import *
from mathematical_constants import *
from quick_functions import *
